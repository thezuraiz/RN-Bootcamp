import React from "react";
import { Text, View } from "react-native";

const onBoarding = () => {
  return (
    <View>
      <Text>onBoarding Screen</Text>
    </View>
  );
};

export default onBoarding;
